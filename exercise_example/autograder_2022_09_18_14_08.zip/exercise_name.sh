exercise_name = exercise_example
